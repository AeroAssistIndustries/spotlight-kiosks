<?php
/**
 * Receives audit requests, messages and support requests when Delivery is "WordPress":
 * saves each one under Inquiries and emails it.
 * @package LandmarkDigital
 */
defined( 'ABSPATH' ) || exit;

add_action( 'init', function () {
	register_post_type( 'cpd_submission', array(
		'labels'          => array( 'name' => 'Inquiries', 'singular_name' => 'Inquiry', 'menu_name' => 'Inquiries' ),
		'public'          => false,
		'show_ui'         => true,
		'menu_icon'       => 'dashicons-email-alt',
		'menu_position'   => 25,
		'supports'        => array( 'title', 'editor' ),
		'capability_type' => 'post',
		'capabilities'    => array( 'create_posts' => 'do_not_allow' ),
		'map_meta_cap'    => true,
	) );
} );

add_action( 'wp_ajax_landmark_submit', 'cpd_handle_submit' );
add_action( 'wp_ajax_nopriv_landmark_submit', 'cpd_handle_submit' );

function cpd_handle_submit() {
	// Spam guards: hidden honeypot field and a simple per-visitor rate limit.
	if ( ! empty( $_POST['_gotcha'] ) ) { // phpcs:ignore
		wp_send_json_success();
	}
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$key = 'cpd_rl_' . md5( $ip );
	$n   = (int) get_transient( $key );
	if ( $n >= 10 ) {
		wp_send_json_error( array( 'message' => 'Too many submissions. Please try again in a few minutes.' ), 429 );
	}
	set_transient( $key, $n + 1, 10 * MINUTE_IN_SECONDS );

	$fields = array();
	foreach ( $_POST as $k => $v ) { // phpcs:ignore
		if ( 'action' === $k || '_' === $k[0] || 'ack' === $k || is_array( $v ) || '' === trim( (string) $v ) ) {
			continue;
		}
		$fields[ sanitize_text_field( str_replace( '_', ' ', $k ) ) ] = sanitize_textarea_field( wp_unslash( $v ) );
	}
	if ( ! $fields ) {
		wp_send_json_error( array( 'message' => 'Empty submission.' ), 400 );
	}
	$subject = isset( $_POST['_subject'] ) ? sanitize_text_field( wp_unslash( $_POST['_subject'] ) ) : 'Website inquiry'; // phpcs:ignore
	$reply   = isset( $_POST['_replyto'] ) ? sanitize_email( wp_unslash( $_POST['_replyto'] ) ) : ''; // phpcs:ignore
	if ( ! $reply && isset( $fields['email'] ) ) {
		$reply = sanitize_email( $fields['email'] );
	}

	$rows = '';
	foreach ( $fields as $k => $v ) {
		$rows .= '<tr><th style="text-align:left;padding:6px 12px;background:#f4f6f7">' . esc_html( ucfirst( $k ) ) . '</th><td style="padding:6px 12px">' . nl2br( esc_html( $v ) ) . '</td></tr>';
	}
	$html = '<table style="border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px">' . $rows . '</table>';

	$post_id = wp_insert_post( array(
		'post_type'    => 'cpd_submission',
		'post_status'  => 'private',
		'post_title'   => $subject,
		'post_content' => $html,
	) );
	if ( $post_id && ! is_wp_error( $post_id ) ) {
		update_post_meta( $post_id, '_cpd_fields', $fields );
	}

	$headers = array( 'Content-Type: text/html; charset=UTF-8' );
	if ( $reply ) {
		$headers[] = 'Reply-To: ' . $reply;
	}
	$mailed = wp_mail( cpd_opt( 'forms_to' ), $subject, $html . '<p style="font-family:Arial;font-size:12px;color:#666">Also saved in WordPress → Inquiries.</p>', $headers );

	wp_send_json_success( array( 'saved' => (bool) $post_id, 'mailed' => (bool) $mailed ) );
}
