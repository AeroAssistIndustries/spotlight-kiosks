<?php
/**
 * Settings → Landmark Digital: form delivery and page tools.
 * @package LandmarkDigital
 */
defined( 'ABSPATH' ) || exit;

function cpd_defaults() {
	return array( 'forms_provider' => 'wordpress', 'forms_to' => 'sarvesh@landmarkdigi.com', 'formspree' => '', 'pay_launch' => '', 'pay_grow' => '', 'pay_scale' => '' );
}
function cpd_opt( $key ) {
	$o = wp_parse_args( get_option( 'cpd_settings', array() ), cpd_defaults() );
	return $o[ $key ];
}

/** What the browser needs (no secrets). */
function cpd_public_config() {
	$provider = cpd_opt( 'forms_provider' );
	return array(
		'forms' => array(
			'provider' => $provider,
			'to'       => 'formsubmit' === $provider ? cpd_opt( 'forms_to' ) : '',
			'endpoint' => 'formspree' === $provider ? cpd_opt( 'formspree' ) : '',
			'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
		),
		'payments' => array( 'provider' => 'stripe', 'launch' => cpd_opt( 'pay_launch' ), 'grow' => cpd_opt( 'pay_grow' ), 'scale' => cpd_opt( 'pay_scale' ) ),
		'maxUploadMB' => 5,
	);
}

add_action( 'admin_menu', function () {
	add_options_page( 'Landmark Digital settings', 'Landmark Digital', 'manage_options', 'landmarkdigital', 'cpd_settings_page' );
} );

add_action( 'admin_init', function () {
	register_setting( 'landmarkdigital', 'cpd_settings', array(
		'type'              => 'array',
		'sanitize_callback' => function ( $in ) {
			$d   = cpd_defaults();
			$out = array();
			$out['forms_provider'] = in_array( $in['forms_provider'] ?? '', array( 'wordpress', 'formsubmit', 'formspree', 'none' ), true ) ? $in['forms_provider'] : $d['forms_provider'];
			$out['forms_to']       = sanitize_email( $in['forms_to'] ?? '' ) ?: $d['forms_to'];
			$out['formspree']      = esc_url_raw( $in['formspree'] ?? '' );
			foreach ( array( 'pay_launch', 'pay_grow', 'pay_scale' ) as $k ) {
				$out[ $k ] = esc_url_raw( $in[ $k ] ?? '' );
			}
			return $out;
		},
	) );
} );

function cpd_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$o = wp_parse_args( get_option( 'cpd_settings', array() ), cpd_defaults() );
	$n = 'cpd_settings';
	?>
	<div class="wrap">
		<h1>Landmark Digital settings</h1>
		<?php if ( isset( $_GET['cpd_pages'] ) ) : // phpcs:ignore ?>
			<div class="notice notice-success"><p><?php echo esc_html( sprintf( 'Pages checked: %d created, %d updated.', (int) $_GET['created'], (int) $_GET['updated'] ) ); // phpcs:ignore ?></p></div>
		<?php endif; ?>
		<form method="post" action="options.php">
			<?php settings_fields( 'landmarkdigital' ); ?>
			<h2>Forms</h2>
			<table class="form-table" role="presentation">
				<tr><th scope="row">Delivery</th><td>
					<select name="<?php echo esc_attr( $n ); ?>[forms_provider]">
						<?php foreach ( array( 'wordpress' => 'WordPress (saved under Inquiries and emailed)', 'formsubmit' => 'FormSubmit (email only, no WordPress copy)', 'formspree' => 'Formspree', 'none' => 'Off — visitors email you themselves' ) as $k => $label ) : ?>
							<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $o['forms_provider'], $k ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
					<p class="description">“WordPress” stores every audit request, message and support request in the admin and emails it. Make sure the site can send email — an SMTP plugin is recommended.</p>
				</td></tr>
				<tr><th scope="row"><label for="cpd-to">Send to</label></th><td><input id="cpd-to" type="email" class="regular-text" name="<?php echo esc_attr( $n ); ?>[forms_to]" value="<?php echo esc_attr( $o['forms_to'] ); ?>"></td></tr>
				<tr><th scope="row"><label for="cpd-fs">Formspree endpoint</label></th><td><input id="cpd-fs" type="url" class="regular-text" placeholder="https://formspree.io/f/xxxx" name="<?php echo esc_attr( $n ); ?>[formspree]" value="<?php echo esc_attr( $o['formspree'] ); ?>"><p class="description">Only used when Delivery is Formspree.</p></td></tr>
				<tr><th scope="row">Stripe Payment Links</th><td>
					<p><label for="cpd-pl">Launch ($899/mo)</label><br><input id="cpd-pl" type="url" class="regular-text" placeholder="https://buy.stripe.com/…" name="<?php echo esc_attr( $n ); ?>[pay_launch]" value="<?php echo esc_attr( $o['pay_launch'] ); ?>"></p>
					<p><label for="cpd-pg">Grow ($1,799/mo)</label><br><input id="cpd-pg" type="url" class="regular-text" placeholder="https://buy.stripe.com/…" name="<?php echo esc_attr( $n ); ?>[pay_grow]" value="<?php echo esc_attr( $o['pay_grow'] ); ?>"></p>
					<p><label for="cpd-ps">Scale ($2,999/mo)</label><br><input id="cpd-ps" type="url" class="regular-text" placeholder="https://buy.stripe.com/…" name="<?php echo esc_attr( $n ); ?>[pay_scale]" value="<?php echo esc_attr( $o['pay_scale'] ); ?>"></p>
					<p class="description">Create one recurring Payment Link per plan in Stripe (Products → Payment Links, monthly). Leave empty to take sign-ups without online payment — the order still arrives by email and you invoice.</p></td></tr>
			</table>
			<?php submit_button(); ?>
		</form>
		<hr>
		<h2>Site pages</h2>
		<p>The theme creates all site pages on activation. Use this to recreate any page that was deleted. Existing pages are left alone unless you tick the box.</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="cpd_pages">
			<?php wp_nonce_field( 'cpd_pages' ); ?>
			<label><input type="checkbox" name="overwrite" value="1"> Also reset existing pages to the theme's original content (overwrites edits)</label>
			<?php submit_button( 'Create missing pages', 'secondary' ); ?>
		</form>
	</div>
	<?php
}

add_action( 'admin_post_cpd_pages', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Not allowed.' );
	}
	check_admin_referer( 'cpd_pages' );
	$r = cpd_install_pages( ! empty( $_POST['overwrite'] ) );
	wp_safe_redirect( add_query_arg( array( 'page' => 'landmarkdigital', 'cpd_pages' => 1, 'created' => $r['created'], 'updated' => $r['updated'] ), admin_url( 'options-general.php' ) ) );
	exit;
} );
