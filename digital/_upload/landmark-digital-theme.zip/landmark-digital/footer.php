<?php
/**
 * Site footer.
 * @package LandmarkDigital
 */
?>
<section class="news-band" aria-labelledby="news-title"><div class="wrap news-grid">
  <div><p class="eyebrow">Stay ahead with us</p><h2 id="news-title">Learn with us &amp; stay connected.</h2><p>One email a month: what changed in local search, reviews and AI answers, and what to do about it. No spam, ever.</p></div>
  <form class="news-form draft-form" id="newsletter" data-to="sarvesh@landmarkdigi.com" data-subject="Newsletter signup" data-review="newsletter-review" data-done="You're on the list. Welcome." novalidate>
    <label class="sr" for="news-email">Email</label><input id="news-email" type="email" name="Email" placeholder="Enter your email" required autocomplete="email"><input type="text" name="_gotcha" class="hp" tabindex="-1" autocomplete="off" aria-hidden="true"><button class="btn" type="submit">Subscribe</button>
    <p class="form-error" role="alert" hidden></p><p class="fine">We won't distribute or sell your information. <a href="<?php echo esc_url( home_url( '/' ) ); ?>privacy/">Privacy policy</a>.</p>
  </form>
  <div class="draft-review" id="newsletter-review" hidden><h3 tabindex="-1">Almost there.</h3><p class="review-lede">We couldn't add you automatically — open the email and press send.</p><pre></pre><div class="btn-row"><button class="btn" type="button" data-draft="open">Open in email</button><button class="btn btn-ghost" type="button" data-draft="edit">Try again</button></div><p class="copied" role="status"></p></div>
  <div class="form-done" id="newsletter-done" hidden><span class="done-ico"><svg class="" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span><h3 tabindex="-1">You're in.</h3><p>Welcome — the next issue will find you.</p></div>
</div></section>
<footer class="site-footer">
  <div class="wrap footer-grid">
    <div class="footer-brand"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/' ) ); ?>logo-stacked-light.svg" alt="Landmark Digital" width="603" height="307"><p>Websites, search, social and reputation for businesses that want to be found — and chosen.</p>
      <p class="footer-addr"><b>Headquarters</b>4750 S 44th Pl, Suite E20<br>Phoenix, AZ 85040</p>
      <p class="footer-addr"><b>Sales</b><a href="tel:+16028874058">602-887-4058</a><b>Support</b><a href="mailto:sarvesh@landmarkdigi.com">sarvesh@landmarkdigi.com</a><b>Email</b><a href="mailto:sarvesh@landmarkdigi.com">sarvesh@landmarkdigi.com</a></p></div>
    <div><h2>Services</h2><nav aria-label="Services"><a href="<?php echo esc_url( home_url( '/' ) ); ?>services/websites/">Websites</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>services/seo/">SEO</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>services/social-media/">Social media</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>services/reputation/">Reputation</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>services/local-listings/">Local listings</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>services/ai-search/">AI search (GEO)</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>pricing/">Pricing</a></nav></div>
    <div><h2>Industries</h2><nav aria-label="Industries"><a href="<?php echo esc_url( home_url( '/' ) ); ?>industries/hotels/">Hotels & hospitality</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>industries/restaurants/">Restaurants & bars</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>industries/medical/">Medical & dental</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>industries/automotive/">Car dealerships & auto services</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>industries/home-services/">Home services & professionals</a></nav></div>
    <div><h2>Company</h2><nav aria-label="Company"><a href="<?php echo esc_url( home_url( '/' ) ); ?>about/">About us</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>how-we-work/">How we work</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>customer-stories/">Customer stories</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>work/">Our work</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>resources/">Guides & resources</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>faqs/">Common questions</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>contact/">Contact us</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>support/">Client support</a></nav></div>
    <div><h2>Landmark</h2><nav aria-label="Landmark"><a href="<?php echo esc_url( home_url( '/' ) ); ?>free-audit/">Free digital audit</a><a href="https://citypulsekiosks.com/">CityPulse Kiosks</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>terms/">Terms & Conditions</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>privacy/">Privacy Policy</a></nav></div>
  </div>
  <div class="wrap footer-base"><span>© <?php echo esc_html( gmdate( 'Y' ) ); ?> Landmark Digital LLC. All rights reserved.</span><nav aria-label="Legal"><a href="<?php echo esc_url( home_url( '/' ) ); ?>privacy/">Privacy Policy</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>terms/">Terms &amp; Conditions</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>contact/">Contact</a></nav></div>
</footer>
<div class="m-cta" id="m-cta"><span><b>Free digital audit</b>See how you rank, in 2 business days</span><a class="btn" href="<?php echo esc_url( home_url( '/' ) ); ?>free-audit/">Get it</a></div>
<?php wp_footer(); ?>
</body>
</html>
