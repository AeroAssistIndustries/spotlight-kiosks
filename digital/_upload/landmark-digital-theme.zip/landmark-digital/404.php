<?php
/**
 * 404 page.
 * @package LandmarkDigital
 */
get_header(); ?>
<main id="main">

<section class="page-hero dark"><div class="wrap narrow"><p class="eyebrow">404</p><h1>That page moved on.</h1><p class="lede">Try one of these instead.</p><div class="btn-row"><a class="btn " href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a><a class="btn btn-ghost" href="<?php echo esc_url( home_url( '/' ) ); ?>services/">Services</a><a class="btn btn-ghost" href="<?php echo esc_url( home_url( '/' ) ); ?>free-audit/">Free audit</a></div></div></section>
</main>
<?php get_footer();
