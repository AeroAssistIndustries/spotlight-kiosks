<?php
/**
 * Landmark Digital theme functions.
 * @package LandmarkDigital
 */
defined( 'ABSPATH' ) || exit;

define( 'CPD_VERSION', '2.2.0' );

require get_theme_file_path( 'inc/settings.php' );
require get_theme_file_path( 'inc/setup.php' );
require get_theme_file_path( 'inc/forms.php' );

add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'html5', array( 'script', 'style', 'search-form', 'gallery', 'caption' ) );
	add_theme_support( 'responsive-embeds' );
} );

/** Styles and scripts. Each script checks for its own elements, so loading them on every page is safe. */
add_action( 'wp_enqueue_scripts', function () {
	$v   = CPD_VERSION;
	$uri = get_theme_file_uri( 'assets/' );
	wp_enqueue_style( 'cpd-fonts', 'https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700;12..96,800&family=Instrument+Sans:wght@400;500;600&family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;1,9..144,400&display=swap', array(), null );
	wp_enqueue_style( 'cpd', $uri . 'styles.css', array( 'cpd-fonts' ), $v );
	wp_enqueue_style( 'cpd-future', $uri . 'future.css', array( 'cpd' ), $v );
	wp_enqueue_style( 'cpd-checkout', $uri . 'checkout.css', array( 'cpd-future' ), $v );
	wp_enqueue_script( 'cpd-integrations', $uri . 'integrations.js', array(), $v, true );
	wp_add_inline_script( 'cpd-integrations', 'window.LANDMARK_CONFIG = ' . wp_json_encode( cpd_public_config() ) . ';', 'before' );
	if ( is_front_page() ) {
		wp_enqueue_script( 'cpd-home', $uri . 'home.js', array(), $v, true );
		wp_enqueue_script( 'cpd-hero', $uri . 'hero-fx.js', array(), $v, true );
	}
	if ( is_front_page() || is_page( array( 'free-audit', 'how-we-work' ) ) ) {
		wp_enqueue_script( 'cpd-labs', $uri . 'labs.js', array(), $v, true );
	}
	if ( is_page( array( 'get-started', 'welcome' ) ) ) {
		wp_enqueue_script( 'cpd-checkout', $uri . 'checkout.js', array( 'cpd-integrations' ), $v, true );
	}
	if ( is_page( 'free-audit' ) ) {
		wp_enqueue_script( 'cpd-scorecard', $uri . 'scorecard.js', array(), $v, true );
	}
	wp_enqueue_script( 'cpd-site', $uri . 'site.js', array( 'cpd-integrations' ), $v, true );
	wp_enqueue_script( 'cpd-fx', $uri . 'fx.js', array( 'cpd-site' ), $v, true );
} );

/** Icons, meta description and social tags. */
add_action( 'wp_head', function () {
	$uri = get_theme_file_uri( 'assets/' );
	$seo_plugin = defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' );
	$desc = is_singular() ? get_post_meta( get_the_ID(), '_cpd_desc', true ) : '';
	if ( ! $desc ) {
		$desc = get_bloginfo( 'description' );
	}
	if ( ! $seo_plugin ) {
		echo '<meta name="description" content="' . esc_attr( $desc ) . "\">\n";
		echo '<meta property="og:title" content="' . esc_attr( wp_get_document_title() ) . "\">\n";
		echo '<meta property="og:description" content="' . esc_attr( $desc ) . "\">\n";
		echo '<meta property="og:image" content="' . esc_url( $uri . 'og-card.png' ) . "\">\n";
		echo "<meta property=\"og:image:width\" content=\"1200\">\n<meta property=\"og:image:height\" content=\"630\">\n";
		echo "<meta property=\"og:site_name\" content=\"Landmark Digital\">\n";
		echo "<meta name=\"twitter:card\" content=\"summary_large_image\">\n";
		echo '<meta name="twitter:title" content="' . esc_attr( wp_get_document_title() ) . "\">\n";
		echo '<meta name="twitter:description" content="' . esc_attr( $desc ) . "\">\n";
		echo '<meta name="twitter:image" content="' . esc_url( $uri . 'og-card.png' ) . "\">\n";
		echo "<meta property=\"og:type\" content=\"website\">\n<meta property=\"og:locale\" content=\"en_US\">\n";
		if ( is_singular() ) {
			echo '<meta property="og:url" content="' . esc_url( get_permalink() ) . "\">\n";
			echo '<link rel="canonical" href="' . esc_url( get_permalink() ) . "\">\n";
		} elseif ( is_front_page() ) {
			echo '<meta property="og:url" content="' . esc_url( home_url( '/' ) ) . "\">\n";
			echo '<link rel="canonical" href="' . esc_url( home_url( '/' ) ) . "\">\n";
		}
		if ( is_404() || is_search() ) {
			echo "<meta name=\"robots\" content=\"noindex\">\n";
		}
	}
	echo "<meta name=\"theme-color\" content=\"#F5F8FF\">\n";
	if ( ! has_site_icon() ) {
		echo '<link rel="icon" href="' . esc_url( $uri . 'favicon.svg' ) . "\" type=\"image/svg+xml\">\n";
		echo '<link rel="icon" href="' . esc_url( $uri . 'favicon.png' ) . "\" type=\"image/png\" sizes=\"64x64\">\n";
		echo '<link rel="apple-touch-icon" href="' . esc_url( $uri . 'apple-touch-icon.png' ) . "\">\n";
		echo '<link rel="manifest" href="' . esc_url( $uri . 'site.webmanifest' ) . "\">\n";
	}
	// Local business structured data.
	if ( is_front_page() ) {
		echo '<script type="application/ld+json">' . wp_json_encode( array(
			'@context' => 'https://schema.org', '@type' => 'ProfessionalService', 'name' => 'Landmark Digital',
			'legalName' => 'Landmark Digital LLC', 'url' => home_url( '/' ), 'logo' => $uri . 'logo.png', 'image' => $uri . 'og-card.png',
			'telephone' => '+1-602-887-4058', 'email' => 'sarvesh@landmarkdigi.com',
			'address' => array( '@type' => 'PostalAddress', 'streetAddress' => '4750 S 44th Pl, Suite E20', 'addressLocality' => 'Phoenix', 'addressRegion' => 'AZ', 'postalCode' => '85040', 'addressCountry' => 'US' ),
			'areaServed' => 'US', 'priceRange' => '$$',
			'knowsAbout' => array( 'Website design', 'Search engine optimization', 'Social media management', 'Reputation management', 'Local listings', 'AI search visibility' ),
		) ) . '</script>' . "\n";
	}
}, 1 );

/** FAQ and breadcrumb structured data, derived from the page's own markup. */
add_action( 'wp_footer', function () {
	if ( ! is_page() ) {
		return;
	}
	$html = get_post_field( 'post_content', get_the_ID() );
	$out  = array();
	if ( preg_match_all( '#<details[^>]*>\s*<summary>(.*?)</summary>\s*<div>(.*?)</div>\s*</details>#s', $html, $m ) ) {
		$qa = array();
		foreach ( $m[1] as $i => $q ) {
			$qa[] = array( '@type' => 'Question', 'name' => wp_strip_all_tags( $q ), 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => trim( wp_strip_all_tags( $m[2][ $i ] ) ) ) );
		}
		$out[] = array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $qa );
	}
	if ( preg_match( '#<ol class="crumbs"[^>]*>(.*?)</ol>#s', $html, $c ) && preg_match_all( '#<li[^>]*>(?:<a href="\{\{CP_HOME\}\}([^"]*)">)?(.*?)(?:</a>)?</li>#', $c[1], $li ) ) {
		$items = array();
		foreach ( $li[2] as $i => $name ) {
			$items[] = array( '@type' => 'ListItem', 'position' => $i + 1, 'name' => wp_strip_all_tags( $name ), 'item' => home_url( '/' . $li[1][ $i ] ) );
		}
		$out[] = array( '@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => $items );
	}
	foreach ( $out as $o ) {
		echo '<script type="application/ld+json">' . wp_json_encode( $o, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
	}
} );

/** Page content stores links as {{CP_HOME}} and assets as {{CP_ASSETS}}; resolve them on output. */
function cpd_resolve_tokens( $html ) {
	return strtr( $html, array(
		'{{CP_HOME}}'   => esc_url( home_url( '/' ) ),
		'{{CP_ASSETS}}' => esc_url( get_theme_file_uri( 'assets/' ) ),
	) );
}
add_filter( 'the_content', 'cpd_resolve_tokens', 99 );

/** The site's copy uses straight quotes inside HTML attributes; keep WordPress from curling them. */
add_filter( 'run_wptexturize', function ( $run ) {
	return is_page() ? false : $run;
} );

/** Path of the current request relative to the site root, e.g. "services/seo/". */
function cpd_current_path() {
	static $path = null;
	if ( null === $path ) {
		$req  = wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/', PHP_URL_PATH ); // phpcs:ignore
		$base = wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		$path = ltrim( substr( (string) $req, strlen( (string) $base ) ), '/' );
		if ( $path && '/' !== substr( $path, -1 ) ) {
			$path .= '/';
		}
	}
	return $path;
}
function cpd_current_attr( $href ) {
	if ( cpd_current_path() === $href ) {
		echo ' aria-current="page"';
	}
}
function cpd_current_class( $key, $hrefs ) {
	$p = cpd_current_path();
	if ( $p && ( 0 === strpos( $p, $key ) || in_array( $p, $hrefs, true ) ) ) {
		echo ' current';
	}
}
